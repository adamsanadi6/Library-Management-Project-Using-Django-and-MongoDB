"""LMS URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name = "home"),
    path('student/', views.student, name = "home"),
    path('student/dashboard/<rollNo>/', views.displayBook, name = "displayBook"),
    path('student/dashboard/book/<book_id>/<rollNo>/', views.book, name = "book"),
    path('student/sendrequest/<book_id>/<rollNo>/', views.sendrequest, name = "sendrequest"),
    path('student/booklending/<rollNo>/', views.booklending, name = "booklending"),
    path('student/signup/', views.studentSignup, name = "studentSignup"),
    path('student/login/', views.studentlogin, name = "login"),
    path('student/signinvalidation/', views.signinvalidation, name = "signinvalidation"),
    path('student/returnorwithdraw/<rollNo>/<book_id>/<flag>/', views.returnorwithdraw, name = "returnorwithdraw"),

    path('librarian/', views.librarian, name = "home"),
    path('librarian/signup/', views.librarianSignup, name = "librarianSignup"),
    path('librarian/login/', views.librarianlogin, name = "librarianlogin"),
    path('librarian/signinvalidation/', views.librariansigninvalidation, name = "librariansigninvalidation"),
    path('librarian/addbook/', views.addbook, name = "addbook"),
    path('librarian/insertbook/', views.insertbook, name = "insertbook"),
    path('librarian/dashboard/', views.displayBooks, name = "displayBooks"),
    path('librarian/updatebook/', views.updatebook, name = "updatebook"),
    path('librarian/updatebookdetails/', views.updatebookdetails, name = "updatebookdetails"),
    path('librarian/checkbook/', views.checkbook, name = "checkbook"),
    path('librarian/librarianbooklendings/', views.librarianbooklendings, name = "librarianbooklendings"),
    path('librarian/LibrarianBookRequests/', views.LibrarianBookRequests, name = "LibrarianBookRequests"),
    path('librarian/bookrequest/<rollno>/<book_id>/<status>/', views.bookrequest, name = "bookrequest"),
    
]