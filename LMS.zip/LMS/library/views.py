from datetime import datetime, timedelta
from dbm.ndbm import library
from multiprocessing import context
from tempfile import template
from django.shortcuts import redirect, render
from django.http import HttpResponse,HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from .models import *
import mongoengine
from django.core.paginator import Paginator

# Create your views here.


def home(request):
    return render(request, "library/Home.html")

def student(request):
    return render(request, "library/Student.html", {"error_message":None})

def librarian(request):
    return render(request, "library/Librarian.html")

def studentSignup(request):
    # rollNo = request.POST['rollNo']
    # firstName = request.POST['firstName']
    # lastName = request.POST['lastName']
    # middleName = request.POST['middleName']
    # phoneNumber = request.POST['phoneNumber']
    # email = request.POST['email']
    # password1 = request.POST['password']
    # password2 = request.POST['password2']
    rollNo = request.POST.get('rollNo')
    firstName = request.POST.get('firstName')
    lastName = request.POST.get('lastName')
    middleName = request.POST.get('middleName')
    phoneNumber = request.POST.get('phoneNumber')
    email = request.POST.get('email')
    password1 = request.POST.get('password')
    password2 = request.POST.get('password2')
    error_message = None
    exist = False
    if password1 != password2:
        error_message = "Password did not match"
        exist = True
    else:
        studentObjects_list = list()
        for stdnt in Student.objects():
            studentObjects_list.append(stdnt.to_json())


        for stdnt in studentObjects_list:
            if stdnt['rollno'] == int(rollNo):
                error_message = "Roll No '" + rollNo + "' Already Exist"
                exist = True
                break
            if stdnt['email_id'] == email:
                error_message = "Email Id '" + email + "' Already Exist"
                exist = True
                break
    if exist:
        return render(request, "library/Student.html", {"error_message" : error_message})
    
    student = Student(rollno = rollNo, firstname = firstName, lastname = lastName, middlename = middleName, phone_number = phoneNumber, email_id = email, password = password1)
    student.save()
    return redirect("/student/dashboard/" + rollNo + "/")
    # return render(request, "library/StudentLibraryPannel.html", {"rollNo" : rollNo, "booksObjects_list" : booksObjects_list})

def studentlogin(request):
    return render(request, "library/StudentLogin.html")

def signinvalidation(request):
    email = request.POST.get('email')
    password = request.POST.get('password')
    try:
        student = Student.objects.get(email_id = email, password = password)
        student = student.to_json()
        rollno = student['rollno']
        url = "/student/dashboard/" + str(rollno) + "/"
        return redirect(url)
    except:
        return render(request, "library/StudentLogin.html", {"error_message" : "Invalid Email Id or Password"})



def librarianlogin(request):
    return render(request, "library/LibrarianLogin.html")


def librarianSignup(request):
    empId = request.POST['empId']
    firstName = request.POST['firstName']
    lastName = request.POST['lastName']
    middleName = request.POST['middleName']
    phoneNumber = request.POST['phoneNumber']
    email = request.POST['email']
    password1 = request.POST['password']
    password2 = request.POST['password2']
    error_message = None
    exist = False
    if password1 != password2:
        error_message = "Password did not match"
        exist = True
    else:
        librarianObjects_list = list()
        for librarian in Librarian.objects():
            librarianObjects_list.append(librarian.to_json())


        for librarian in librarianObjects_list:
            if librarian['empId'] == empId:
                error_message = "Employee Id '" + empId + "' Already Exist"
                exist = True
                break
            if librarian['email_id'] == email:
                error_message = "Email Id '" + email + "' Already Exist"
                exist = True
                break
    if exist:
        return render(request, "library/Librarian.html", {"error_message" : error_message})

    librarian = Librarian(empId = empId, firstname = firstName, lastname = lastName, middlename = middleName, phone_number = phoneNumber, email_id = email, password = password1)
    librarian.save()
    return redirect("/librarian/dashboard/")



def librariansigninvalidation(request):
    email = request.POST.get('email')
    password = request.POST.get('password')
    try:
        if email and password:
            librarian = Librarian.objects.get(email_id = email, password = password)
        booksObjects_list = list()
        for book in Books.objects().order_by("bookName"):
            booksObjects_list.append(book.to_json())
            
        paginator = Paginator(booksObjects_list, 8)
        page = request.GET.get('page')
        booksObjects_list = paginator.get_page(page)
        return render(request, "library/LibrarianLibraryPannel.html", {"booksObjects_list": booksObjects_list})
    except Exception:
        return render(request, "library/LibrarianLogin.html", {"error_message" : "Invalid Email Id or Password"})


def addbook(request):
    return render(request, "library/AddBook.html")

def insertbook(request):
    book_id = request.POST["book_id"]
    bookName = request.POST["bookName"]
    author = request.POST["author"]
    description = request.POST["description"]
    image = request.POST["image"]
    no_of_copies = request.POST["no_of_copies"]
    image = "library/" + image
    error_message = "Book Added Successfully"
    exist = False
    booksObjects_list = list()
    for book in Books.objects():
        booksObjects_list.append(book.to_json())


    for book in booksObjects_list:
        if book['book_id'] == int(book_id):
            error_message = "Book Id '" + book_id + "' Already Exist"
            exist = True
            break

    if exist:
        return render(request, "library/AddBook.html", {"error_message" : error_message})

    book = Books(book_id = book_id, bookName = bookName, author = author, description = description, image = image, no_of_copies = no_of_copies)
    book.save()
    return render(request, "library/AddBook.html", {"error_message" : error_message})


def displayBooks(request):
    booksObjects_list = list()
    key = request.POST.get('search')
    if key and len(key) > 0:
        exist = False
        for book in Books.objects().order_by("bookName"):
            book = book.to_json()
            if str(book['book_id']) == key:
                booksObjects_list.append(book)
                exist = True
            elif key.lower() in book['bookName'].lower():
                booksObjects_list.append(book)
                exist = True
            elif key.lower() in book['author'].lower():
                booksObjects_list.append(book)
                exist = True
        if not(exist):
            return render(request, "library/LibrarianLibraryPannel.html", {"error_message" : "There is No Such Book Available"})
        return render(request, "library/LibrarianLibraryPannel.html", {"booksObjects_list" : booksObjects_list})
    booksObjects_list = list()
    for book in Books.objects().order_by("bookName"):
        booksObjects_list.append(book.to_json())
    paginator = Paginator(booksObjects_list, 8)
    page = request.GET.get('page')
    booksObjects_list = paginator.get_page(page)
    return render(request, "library/LibrarianLibraryPannel.html", {"booksObjects_list": booksObjects_list})


def displayBook(request, rollNo):
    booksObjects_list = list()
    key = request.POST.get('search')
    bookapproved_list = list()
    bookpending_list = list()
    for book in Booklending.objects():
        books = book.to_json()
        if books['returned']:
            continue
        if books['rollno'] == int(rollNo):
            if  books['pending'] == 1:
                bookpending_list.append(books['book_id'])
            elif books['approved'] == 1:
                bookapproved_list.append(books['book_id'])
    
    exceeded = False
    if len(bookapproved_list) + len(bookpending_list) >= 5:
        exceeded = True
    if key and len(key) > 0:
        exist = False
        for book in Books.objects().order_by("bookName"):
            book = book.to_json()
            if key.lower() in book['bookName'].lower():
                if book['book_id'] in bookapproved_list:
                    last = False
                    for books in Booklending.objects.filter(rollno = rollNo, book_id = book['book_id'], approved = 1, returned = False).order_by("-id"):
                        last = books.to_json()
                    book['approved'] = True
                    date = last['date']
                    date = datetime.strptime(date, "%d-%m-%Y")
                    date = date + timedelta(days=7)
                    year = date.strftime("%Y")
                    month = date.strftime("%m")
                    day = date.strftime("%d")
                    date = day + "-" + month + "-" + year
                    book['duedate'] = date
                elif book['book_id'] in bookpending_list:
                    book['requested'] = True
                elif book["no_of_copies"] == 0:
                    book['empty'] = True
                else:
                    last = ""
                    for books in Booklending.objects.filter(rollno = rollNo):
                        books = books.to_json()
                        if books['book_id'] == book['book_id'] and books['pending'] == 0 and books['approved'] == 0:
                            last = books
                        elif books['book_id'] == book['book_id'] and books['pending'] == 1:
                            last = ""
                        elif books['book_id'] == book['book_id'] and (books['pending'] == 0 and books['approved'] == 1):
                            last = ""
                    if last != "":
                        date1 = last['date']
                        now = datetime.now() # current date and time
                        year = now.strftime("%Y")
                        month = now.strftime("%m")
                        day = now.strftime("%d")
                        date2 = day + "-" + month + "-" + year
                        format = "%d-%m-%Y"
                        date1 = datetime.strptime(date1, format)
                        date2 = datetime.strptime(date2, format)
                        difference = (date2 - date1).days
                        if difference < 1:
                            book['difference'] = True
                book['exceeded'] = exceeded
                booksObjects_list.append(book)
                exist = True
            elif key.lower() in book['author'].lower():
                if book['book_id'] in bookapproved_list:
                    last = False
                    for books in Booklending.objects.filter(rollno = rollNo, book_id = book['book_id'], approved = 1, returned = False).order_by("-id"):
                        last = books.to_json()
                    book['approved'] = True
                    date = last['date']
                    date = datetime.strptime(date, "%d-%m-%Y")
                    date = date + timedelta(days=7)
                    year = date.strftime("%Y")
                    month = date.strftime("%m")
                    day = date.strftime("%d")
                    date = day + "-" + month + "-" + year
                    book['duedate'] = date
                elif book['book_id'] in bookpending_list:
                    book['requested'] = True
                elif book["no_of_copies"] == 0:
                    book['empty'] = True
                else:
                    last = ""
                    for books in Booklending.objects.filter(rollno = rollNo):
                        books = books.to_json()
                        if books['book_id'] == book['book_id'] and books['pending'] == 0 and books['approved'] == 0:
                            last = books
                        elif books['book_id'] == book['book_id'] and (books['pending'] == 1 and books['approved'] == 0):
                            last = ""
                        elif books['book_id'] == book['book_id'] and (books['pending'] == 0 and books['approved'] == 1):
                            last = ""
                    if last != "":
                        date1 = last['date']
                        now = datetime.now() # current date and time
                        year = now.strftime("%Y")
                        month = now.strftime("%m")
                        day = now.strftime("%d")
                        date2 = day + "-" + month + "-" + year
                        format = "%d-%m-%Y"
                        date1 = datetime.strptime(date1, format)
                        date2 = datetime.strptime(date2, format)
                        difference = (date2 - date1).days
                        if difference < 1:
                            book['difference'] = True
                book['exceeded'] = exceeded
                booksObjects_list.append(book)
                exist = True
        if not(exist):
            return render(request, "library/StudentLibraryPannel.html", {"error_message" : "There is No Such Book Available", "rollNo" : rollNo})
        paginator = Paginator(booksObjects_list, 8)
        page = request.GET.get('page')
        booksObjects_list = paginator.get_page(page)
        return render(request, "library/StudentLibraryPannel.html", {"booksObjects_list" : booksObjects_list, "rollNo" : rollNo})
    for book in Books.objects().order_by("bookName"):
        book_detail = book.to_json()
        book_detail['exceeded'] = exceeded
        if book_detail['book_id'] in bookapproved_list:
            book_detail['approved'] = True
            booklendings = Booklending.objects.get(rollno = rollNo, book_id = book_detail['book_id'], approved = 1, returned = False)
            date = booklendings['date']
            date = datetime.strptime(date, "%d-%m-%Y")
            date = date + timedelta(days=7)
            year = date.strftime("%Y")
            month = date.strftime("%m")
            day = date.strftime("%d")
            date = day + "-" + month + "-" + year
            book_detail['duedate'] = date
        elif book_detail['book_id'] in bookpending_list:
            book_detail['requested'] = True
        elif book_detail["no_of_copies"] == 0:
            book_detail['empty'] = True
        else:
            last = ""
            for books in Booklending.objects.filter(rollno = rollNo):
                books = books.to_json()
                if books['returned']:
                    continue
                if books['book_id'] == book_detail['book_id'] and books['pending'] == 0 and books['approved'] == 0:
                    last = books
                elif books['book_id'] == book_detail['book_id'] and (books['pending'] == 1 and books['approved'] == 0):
                    last = ""
                elif books['book_id'] == book_detail['book_id'] and (books['pending'] == 0 and books['approved'] == 1):
                    last = ""
            if last != "":
                date1 = last['date']
                now = datetime.now() # current date and time
                year = now.strftime("%Y")
                month = now.strftime("%m")
                day = now.strftime("%d")
                date2 = day + "-" + month + "-" + year
                format = "%d-%m-%Y"
                date1 = datetime.strptime(date1, format)
                date2 = datetime.strptime(date2, format)
                difference = (date2 - date1).days
                if difference < 1:
                    book_detail['difference'] = True
        booksObjects_list.append(book_detail)
    #Pagination Part
    paginator = Paginator(booksObjects_list, 8)
    page = request.GET.get('page')
    booksObjects_list = paginator.get_page(page)

    return render(request, "library/StudentLibraryPannel.html", {"booksObjects_list": booksObjects_list, "rollNo":rollNo})

def book(request, book_id, rollNo):
    try:
        book = Booklending.objects.get(book_id = book_id, rollno = rollNo, pending = 1).to_json()
        book = Books.objects.get(book_id = book_id).to_json()
        bookName = book['bookName']
        author = book['author']
        image = book['image']
        description = book['description']
        return render(request, "library/book.html", {"book_id" : book_id, "bookName" : bookName, "author" : author, "image" : image, "description" : description, "rollNo" : rollNo, "visited" : True})
    except:
        book = Books.objects.get(book_id = book_id).to_json()
        bookName = book['bookName']
        author = book['author']
        image = book['image']
        description = book['description']
        return render(request, "library/book.html", {"book_id" : book_id, "bookName" : bookName, "author" : author, "image" : image, "description" : description, "rollNo" : rollNo})


def updatebook(request):
    return render(request, "library/UpdateBookLibrarian.html" , {"nothing":None})

def checkbook(request):
    book_id = request.POST['book_id']
    exist = False
    book_details = ""
    for book in Books.objects():
        book = book.to_json()
        if str(book['book_id']) == book_id:
            book_details = book
            exist = True
            break
    if not(exist):
        return render(request, "library/UpdateBookLibrarian.html", {"error_message" : "There is No Such Book Available"})
    return render(request, "library/UpdateBookLibrarian.html", {"book_id" : book_details['book_id'], "bookName" : book_details['bookName'], 'author' : book_details['author'], 'description' : book_details['description'], 'no_of_copies' : book_details['no_of_copies']})

def updatebookdetails(request):
    book_id = request.POST['book_id']
    bookName = request.POST['bookName']
    author = request.POST['author']
    description = request.POST['description']
    image = request.POST['image']
    no_of_copies = request.POST['no_of_copies']
    book = Books.objects.get(book_id = book_id)
    book.bookName = bookName
    book.author = author
    book.description = description
    book.no_of_copies = no_of_copies
    if len(image) > 0:
        book.image = "library/" + image
    book.save()
    return render(request, "library/UpdateBookLibrarian.html" , {"nothing":None, "success" : "Data Successfully Updated"})


def sendrequest(request, book_id, rollNo):
    book = Books.objects.get(book_id = book_id)
    if book.no_of_copies == 0:
        book = book.to_json()
        bookName = book['bookName']
        author = book['author']
        image = book['image']
        description = book['description']
        return render(request, "library/book.html", {"book_id" : book_id, "bookName" : bookName, "author" : author, "image" : image, "description" : description, "rollNo" : rollNo, "not_available" : True})
    
    now = datetime.now() # current date and time
    year = now.strftime("%Y")
    month = now.strftime("%m")
    day = now.strftime("%d")
    date = day + "-" + month + "-" + year
    booklending = Booklending(book_id = book_id, rollno = rollNo, pending = 1, approved = 0, date = date)
    booklending.save()
    book.no_of_copies -= 1
    book.save()
    book = book.to_json()
    bookName = book['bookName']
    author = book['author']
    image = book['image']
    description = book['description']
    return render(request, "library/book.html", {"book_id" : book_id, "bookName" : bookName, "author" : author, "image" : image, "description" : description, "rollNo" : rollNo, "visited" : True})

def booklending(request, rollNo):
    booklending_list = list()
    for book in Booklending.objects.filter(rollno = rollNo).order_by("date"):
        books = book.to_json()
        book_id = books['book_id']
        date = books['date']
        if date == "":
           date = "-" 
        status = "Rejected"
        if books['returned']:
            status = "Returned"
        elif books['pending'] == 1:
            status = "Pending"
        elif book['approved'] == 1:
            status = "Approved"
        bookObj = Books.objects.get(book_id = book_id).to_json()
        bookName = bookObj['bookName']
        author = bookObj['author']
        booklending_list.append({'book_id' : book_id, 'bookName' : bookName, 'author' : author, 'status' : status, 'date' : date})
    if len(booklending_list) == 0:
        return  render(request, "library/BookLending.html", {"booklending_list" : booklending_list, "rollNo" : rollNo, 'error_message' : "Sorry No Record Found"})

    return  render(request, "library/BookLending.html", {"booklending_list" : booklending_list, "rollNo" : rollNo})


def librarianbooklendings(request):
    booklending_object_list = list()
    for student in Student.objects().order_by("rollno"):
        student = student.to_json()
        rollno = student['rollno']
        firstname = student['firstname']
        middlename = student['middlename']
        lasname = student['lastname']
        name = firstname
        if middlename != "":
            name = name + " " + middlename + " " + lasname
        else:
            name = name + " " + lasname
        books = list()
        for book in Booklending.objects.filter(rollno = rollno, returned = False):
            book = book.to_json()
            if book['approved'] == 0 :
                continue
            book_id = book['book_id']
            book = Books.objects.get(book_id = book_id).to_json()
            bookName = book['bookName']
            author = book['author']
            books.append({"book_id" : book_id, "bookName" : bookName, "author" : author})
        if len(books) == 0:
            continue
        booklending_object_list.append({"rollno" : rollno, "name" : name, "books" : books})

    key = request.POST.get('search')
    booklending_object_list2 = list()
    if key and len(key) > 0:
        for details in booklending_object_list:
            if str(details['rollno']) == key:
                booklending_object_list2.append(details)
            elif key.lower() in details['name'].lower():
                booklending_object_list2.append(details)
        booklending_object_list = booklending_object_list2

    if len(booklending_object_list) == 0:
        return render(request, "library/LibraryBookLending.html", {"error_message" : "Sorry No Record Found"})
    return render(request, "library/LibraryBookLending.html", {"booklending_object_list" : booklending_object_list})



def LibrarianBookRequests(request):
    booklending_object_list = list()
    for book in Booklending.objects.filter(pending = 1, returned = False):
        book = book.to_json()
        rollno = book['rollno']
        book_id = book['book_id']
        book = Books.objects.get(book_id = book_id).to_json()
        bookName = book['bookName']
        author = book['author']
        student = Student.objects.get(rollno = rollno).to_json()
        firstname = student['firstname']
        middlename = student['middlename']
        lasname = student['lastname']
        name = firstname
        if middlename != "":
            name = name + " " + middlename + " " + lasname
        else:
            name = name + " " + lasname
        booklending_object_list.append({"rollno" : rollno, "name" : name, "book_id" : book_id, "bookName" : bookName, "author" : author})
    
    if len(booklending_object_list) == 0:
        return render(request, "library/LibrarianBookRequests.html", {"error_message" : "Sorry There are No Requests to be Found"})
    return render(request, "library/LibrarianBookRequests.html", {"booklending_object_list" : booklending_object_list})

def bookrequest(request, rollno, book_id, status):
    booklendings = Booklending.objects.get(rollno = rollno, book_id = book_id, pending = 1)
    booklendings.pending = 0
    booklendings.approved = 1
    now = datetime.now() # current date and time
    year = now.strftime("%Y")
    month = now.strftime("%m")
    day = now.strftime("%d")
    booklendings.date = day + "-" + month + "-" + year
    booklendings.save()

    if int(status) == 0:
        booklendings.approved = 0
        book = Books.objects.get(book_id = book_id)
        book.no_of_copies += 1
        book.save()
    return LibrarianBookRequests(request)

def returnorwithdraw(request, rollNo, book_id, flag):
    try:
        if flag == "1":
            books = None
            for b in Booklending.objects.filter(book_id = book_id, rollno = rollNo, approved = 1):
                bks = b.to_json()
                if bks['returned'] == False:
                    b.returned = True
                    now = datetime.now() # current date and time
                    year = now.strftime("%Y")
                    month = now.strftime("%m")
                    day = now.strftime("%d")
                    b.date = day + "-" + month + "-" + year
                    b.save()
        else:
            booklendings = Booklending.objects.get(book_id = book_id, rollno = rollNo, pending = 1)
            booklendings.delete()
        book = Books.objects.get(book_id = book_id)
        book.no_of_copies += 1
        book.save()
        return booklending(request, rollNo)
        
    except:
        return booklending(request, rollNo)