from distutils.command.upload import upload
import email
from email.policy import default
from enum import unique
from mongoengine import Document, fields

class Student(Document):
    rollno = fields.IntField(unique = True)
    firstname = fields.StringField(max_length = 255)
    lastname = fields.StringField(max_length = 255)
    middlename = fields.StringField(max_length = 255)
    phone_number = fields.StringField(max_length = 11)
    email_id = fields.StringField(max_length = 50, unique = True)
    password = fields.StringField(max_length = 17)
    
    def to_json(self):
        return {
            "rollno" : self.rollno,
            "firstname" : self.firstname,
            "middlename" : self.middlename,
            "lastname" : self.lastname,
            "phone_number" : self.phone_number,
            "email_id" : self.email_id,
            "password" : self.password
        } 


class Librarian(Document):
    empId = fields.IntField(max_length = 11, unique = True)
    firstname = fields.StringField(max_length = 255)
    lastname = fields.StringField(max_length = 255)
    middlename = fields.StringField(max_length = 255)
    phone_number = fields.StringField(max_length = 11)
    email_id = fields.StringField(max_length = 50, unique = True)
    password = fields.StringField(max_length = 17)
    
    def to_json(self):
        return {
            "empId" : self.empId,
            "firstname" : self.firstname,
            "middlename" : self.middlename,
            "lastname" : self.lastname,
            "phone_number" : self.phone_number,
            "email_id" : self.email_id,
            "password" : self.password
        } 

class Books(Document):
    book_id = fields.IntField(unique = True)
    bookName = fields.StringField()
    author = fields.StringField()
    description = fields.StringField()
    image = fields.StringField()
    no_of_copies = fields.IntField()
    
    def to_json(self):
        return {
            "book_id" : self.book_id,
            "bookName" : self.bookName,
            "author" : self.author,
            "description" : self.description,
            "image" : self.image,
            "no_of_copies" : self.no_of_copies
        } 

class Booklending(Document):
    book_id = fields.IntField()
    rollno = fields.IntField()
    pending = fields.IntField()
    approved = fields.IntField()
    date = fields.StringField(default = "")
    returned = fields.BooleanField(default = False)
    def to_json(self):
        return {
            "book_id" : self.book_id,
            "rollno" : self.rollno,
            "pending" : self.pending,
            "approved" : self.approved,
            "date" : self.date,
            "returned" : self.returned
        } 